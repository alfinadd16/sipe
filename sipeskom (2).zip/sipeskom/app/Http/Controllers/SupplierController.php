<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Supplier;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Validator;

class SupplierController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Supplier::latest()->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($data) {
                    return '<button type="button" class="btn btn-success btn-sm" id="getEditArticleData" data-id="' . $data->id . '">Edit</button>
                    <button type="button" data-id="' . $data->id . '" data-toggle="modal" data-target="#DeleteArticleModal" class="btn btn-danger btn-sm" id="getDeleteId">Delete</button>';
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view("admin.supplier");
    }

    public function destroy($id)
    {
        $supplier = new Supplier();
        $supplier->deleteData($id);
        return response()->json(['success' => 'berhasil Dihapus']);
    }


    public function store(Request $request, Supplier $supplier)
    {
        $validator = Validator::make($request->all(), [
            'nama' => 'required',
            'alamat' => 'required',
            'no_hp' => 'required',
        ]);


        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors());
        }

        $supplier->storeData($request->all());

        return response()->json(['success' => 'Berhasil Ditambah']);
    }

    public function edit($id)
    {
        $supplier= new Supplier();
        $data = $supplier->findData($id);

        $html = ' <div class="form-group">
                    <label for="nama">Nama:</label>
                    <input type="text" class="form-control" name="nama" id="editNama" value="' . $data->nama . '">
                </div>
                <div class="form-group">
                    <label for="alamat">Alamat:</label>
                    <input type="text" class="form-control" name="alamat" id="editAlamat" value="' . $data->alamat . '">
                </div>
                <div class="form-group">
                <label for="no_hp">Nomor HP:</label>
                <input type="text" class="form-control" name="no_hp" id="editNo_hp" value="' . $data->no_hp . '">
                </div>
                ';

        return response()->json(['html' => $html]);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'nama' => 'required',
            'alamat' => 'required',
            'no_hp' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors());
        }

        $supplier = new Supplier();
        $supplier->updateData($id, $request->all());

        return response()->json(['success' => 'Berhasil Diupdate']);
    }
}
