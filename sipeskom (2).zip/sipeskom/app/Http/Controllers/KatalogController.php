<?php

namespace App\Http\Controllers;

use App\Models\Sparepart;
use App\Models\Kategori;
use Illuminate\Http\Request;

class KatalogController extends Controller
{
    public function cari(Request $request)
    {
        $name = $request->name;
        $spareparts = Sparepart::where('name', 'like', "%" . $name . "%")->paginate(5);
        return view('katalog', [
            'spareparts' => $spareparts,
            'categories' => Kategori::all()
        ]);
    }

    public function render()
    {
        $spareparts = Sparepart::all();
        $category = Kategori::all();
        return view('katalog', [
            'spareparts' => $spareparts,
            'categories' => $category
        ]);
    }
}
