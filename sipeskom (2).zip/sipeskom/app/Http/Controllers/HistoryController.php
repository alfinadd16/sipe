<?php

namespace App\Http\Controllers;

use App\Models\Service;
use Illuminate\Http\Request;
use App\Models\Kategori;
use Auth;
use Alert;
use App\Models\DetailJenisService;
use App\Models\DetailService;
use App\Models\JenisService;
use Barryvdh\DomPDF\Facade as PDF;

class HistoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $bookings = Service::where('user_id', Auth::user()->id)->get();
        $categories = Kategori::all();
        return view('history', compact('bookings', 'categories'));
    }

    public function detail($id)
    {
        $booking = Service::where('id', $id)->first();
        $bookings = Service::where('id', $booking->id)->get();
        $categories = Kategori::all();
        return view('historyDetail', compact('bookings', 'booking', 'categories'));
    }

    public function update(Request $request, $id)
    {
        $booking = Service::findOrFail($id);
        $booking->nama_pemilik = $request->name_stnk;
        $booking->nama_barang = $request->number_plat;
        $booking->alamat = $request->nama_motor;
        $booking->no_telp = $request->jenis_motor;
        $booking->complaint = $request->complaint;
        $booking->update();
        alert()->success('Booking successfully updated', 'Success');
        return redirect('history');
    }

    public function invoice($id)
    {
        $booking = Service::where('id', $id)->first();
        $bookings = Service::where('id', $booking->id)->get();
        $jenisServices = JenisService::all();
        $categories = Kategori::all();
        $service_details = [];
        if (!empty($booking)) {
            $service_details = DetailService::where('service_id', $booking->id)->get();
        }
        $detailJenis = [];
        if (!empty($booking)) {
            $detailJenis  = DetailJenisService::where('service_id', $booking->id)->get();
        }
        return view('invoice', compact('bookings', 'booking', 'jenisServices', 'service_details', 'categories', 'detailJenis'));
    }

    public function index_service()
    {
        $bookings = Service::where('user_id', Auth::user()->id)->get();
        $categories = Kategori::all();
        return view('riwayat', compact('bookings', 'categories'));
    }

    public function detail_service($id)
    {
        $booking = Service::where('id', $id)->first();
        $bookings = Service::where('id', $booking->id)->get();
        $categories = Kategori::all();
        $service_details = [];
        if (!empty($booking)) {
            $service_details = DetailService::where('service_id', $booking->id)->get();
        }
        $detailJenis = [];
        if (!empty($booking)) {
            $detailJenis  = DetailJenisService::where('service_id', $booking->id)->get();
        }
        return view('detailService', compact('bookings', 'booking', 'categories', 'service_details', 'detailJenis'));
    }

    public function cetak_pdf($id)
    {
        $booking = Service::where('id', $id)->first();
        $bookings = Service::where('id', $booking->id)->get();
        $jenisServices = JenisService::all();
        $categories = Kategori::all();
        $service_details = [];
        if (!empty($booking)) {
            $service_details = DetailService::where('service_id', $booking->id)->get();
        }
        $detailJenis = [];
        if (!empty($booking)) {
            $detailJenis  = DetailJenisService::where('service_id', $booking->id)->get();
        }
        $pdf = PDF::loadview('invoice_pdf', ['booking' => $booking, 'bookings' => $bookings, 'jenisServices' => $jenisServices, 'categories' => $categories, 'service_details' => $service_details, 'detailJenis' => $detailJenis])->setPaper('a4', 'portrait');
        return $pdf->stream();
    }
}
