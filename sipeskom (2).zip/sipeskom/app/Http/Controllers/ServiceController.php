<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Kategori;
use Illuminate\Support\Facades\Auth;
use Alert;
use App\Models\Service;

class ServiceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('booking', [
            'categories' => Kategori::all()
        ]);
    }

    public function save(Request $request, $id)
    {
        $user = User::where('id', $id)->first();
        $service = Service::where('user_id', $user->id)->first();
        $service = new Service();
        $service->user_id = $user->id;
        $service->nama_pemilik = $request->nama_pemilik;
        $service->nama_barang = $request->nama_barang;
        $service->alamat = $request->alamat;
        $service->telp = $request->telp;
        $service->service_date = $request->service_date;
        $service->complaint = $request->complaint;
        $service->save();
        alert()->success('Terima Kasih');
        return redirect('history');
    }
}
