<?php

namespace App\Http\Controllers;

use Auth;
use Alert;
use App\Models\User;
use App\Models\Kategori;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ProfilController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
	}

	public function index()
	{
		$user = User::where('id', Auth::user()->id)->first();
		$categories = Kategori::all();
		return view('profil', compact('user', 'categories'));
	}

	public function updatecustomer(Request $request)
	{
		// $this->validate($request, [
		// 	'password'  => 'confirmed',
		// ]);

		$user = User::where('id', Auth::user()->id)->first();
		$user->name = $request->name;
		$user->email = $request->email;
		$user->phoneNumber = $request->phoneNumber;
		$user->address = $request->address;
		// if (!empty($request->password)) {
		// 	$user->password = Hash::make($request->password);
		// }
		$user->update();
		alert()->success('Berhasil Update', 'Success');
		return redirect('profil');
	}

	public function indexAdmin()
	{
		$user = User::where('id', Auth::user()->id)->first();
		$categories = Kategori::all();
		return view('admin.profilAdmin', compact('user', 'categories'));
	}

	public function updateadmin(Request $request)
	{
		$this->validate($request, [
			'password'  => 'confirmed',
		]);

		$user = User::where('id', Auth::user()->id)->first();
		$user->name = $request->name;
		$user->email = $request->email;
		$user->phoneNumber = $request->phoneNumber;
		$user->address = $request->address;
		if (!empty($request->password)) {
			$user->password = Hash::make($request->password);
		}

		$user->update();

		alert()->success('Berhasil Update', 'Success');
		return redirect('profilAdmin');
	}
}
