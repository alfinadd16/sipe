<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use App\Models\Sparepart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KategoriController extends Controller
{
    public function cari(Request $request){
        $name = $request->name;
        $spareparts = Sparepart::where('name','like',"%".$name."%")->paginate(5);
        return view('katalog', [
            'spareparts' => $spareparts,
            'categories' => Kategori::all()
        ]);

    }

    public function render($category)
    {
        $spareparts = DB::table('spareparts')->where('category_id', $category)->get();
        return view('katalog', [
            'spareparts' => $spareparts,
            'categories' => Kategori::all()
        ]);
    }
}
