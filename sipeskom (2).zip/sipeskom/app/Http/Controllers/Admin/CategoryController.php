<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Kategori;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Kategori::latest()->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($data) {
                    return '<button type="button" class="btn btn-success btn-sm" id="getEditArticleData" data-id="' . $data->id . '">Edit</button>
                    <button type="button" data-id="' . $data->id . '" data-toggle="modal" data-target="#DeleteArticleModal" class="btn btn-danger btn-sm" id="getDeleteId">Delete</button>';
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view("admin.category");
    }

    public function destroy($id)
    {
        $category = new Kategori();
        $category->deleteData($id);
        return response()->json(['success' => 'berhasil Dihapus']);
    }

    public function store(Request $request, Kategori $category)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);


        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors());
        }

        $category->storeData($request->all());

        return response()->json(['success' => 'Berhasil Ditambah']);
    }

    public function edit($id)
    {
        $category = new Kategori();
        $data = $category->findData($id);

        $html = '<div class="form-group">
                    <label for="Name">Nama :</label>
                    <input type="text" class="form-control" name="name" id="editTitle" value="' . $data->name . '">
                </div>';

        return response()->json(['html' => $html]);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors());
        }

        $category = new Kategori();
        $category->updateData($id, $request->all());

        return response()->json(['success' => 'Berhasil Diupdate']);
    }
}
