<?php $__env->startSection('title'); ?>
Detail
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <br><br><br>
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(url('history')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('history')); ?>">Booking History</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Booking Detail</li>
                </ol>
            </nav>
        </div>
        <div class="col-md-12">
            <div class="card mt-2">
                <div class="card-body" style="color: black;">
                    <?php if(!empty($booking)): ?>
                    <p  style="color: #008080">Status booking is <?php echo e($booking->status); ?> / A.n <?php echo e($booking->name_stnk); ?> </p>
                    <p >No. Booking : <?php echo e($booking->id); ?> / Booking Date : <?php echo e($booking->service_date); ?></p><br>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 style="color: #8B0000;"><i class="fas fa-history" style="color: #8B0000;"></i> Booking Detail</h4>
                                <table class="table">
                                    <tbody>
                                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>Name of STNK</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->name_stnk); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Motorcycle Name</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->nama_motor); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Motorcycle Type</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->jenis_motor); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Motorcycle license plate</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->number_plat); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Complaint</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->complaint); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 style="color: #8B0000;"><i style="color: #8B0000;" class="fa fa-pencil-alt"></i> Edit Booking</h4>
                    <br>
                    <form method="POST" action="<?php echo e(url('historyEdit')); ?>/<?php echo e($booking->id); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name_stnk" class="col-md-2 col-form-label text-md-right">Name of STNK</label>

                            <div class="col-md-6">
                                <input style="background-color: #ecebeb; color: black;" id="name_stnk" type="text" class="form-control <?php $__errorArgs = ['name_stnk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name_stnk" value="<?php echo e($booking->name_stnk); ?>">

                                <?php $__errorArgs = ['name_stnk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="number_plat" class="col-md-2 col-form-label text-md-right">Motorcycle license plate</label>

                            <div class="col-md-6">
                                <input style="background-color: #ecebeb; color: black;" id="number_plat" type="text" class="form-control <?php $__errorArgs = ['number_plat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="number_plat" value="<?php echo e($booking->number_plat); ?>">

                                <?php $__errorArgs = ['number_plat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="name_motor" class="col-md-2 col-form-label text-md-right">Motorcycle Name</label>

                            <div class="col-md-6">
                                <input style="background-color: #ecebeb; color: black;" id="nama_motor" type="text" class="form-control <?php $__errorArgs = ['nama_motor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_motor" value="<?php echo e($booking->nama_motor); ?>" required autocomplete="nama_motor">

                                <?php $__errorArgs = ['nama_motor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="jenis_motor" class="col-md-2 col-form-label text-md-right">Motorcycle Type</label>

                            <div class="col-md-6">
                                <input style="background-color: #ecebeb; color: black;" id="jenis_motor" type="text" class="form-control <?php $__errorArgs = ['jenis_motor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jenis_motor" value="<?php echo e($booking->jenis_motor); ?>" required autocomplete="jenis_motor" autofocus>

                                <?php $__errorArgs = ['jenis_motor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label for="complaint" class="col-md-2 col-form-label text-md-right">Complaint</label>

                            <div class="col-md-6">
                                <textarea style="background-color: #ecebeb; color: black;" name="complaint" class="form-control <?php $__errorArgs = ['complaint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required=""><?php echo e($booking->complaint); ?></textarea>

                                <?php $__errorArgs = ['complaint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-2">
                                <button type="submit" class="btn btn-primary" style="width: 100%; font-weight: bold; font-size: 16px;">
                                    Save
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asli\resources\views/historyDetail.blade.php ENDPATH**/ ?>