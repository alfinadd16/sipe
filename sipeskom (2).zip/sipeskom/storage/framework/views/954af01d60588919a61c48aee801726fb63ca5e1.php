<?php $__env->startSection('content'); ?>
<div class="container py-4">
<br><br><br>
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(url('history')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                    <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(url('history')); ?>"> History </a></li>
                    <li class="breadcrumb-item active" aria-current="page"> See Payment </li>
                </ol>
            </nav>
        </div>
        <div class="col-md-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h3 style="color: gray;"><i class="far fa-money-bill-alt"></i> See Payment</h3>
                    <table class="table table-striped">
                        <thead>
                            <tr style="color: gray;">
                                <th>Account Name</th>
                                <th>Date</th>
                                <th>Bank</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="color: gray;">
                                    <td><?php echo e($payment->namaRek); ?></td>
                                    <td><?php echo e($payment->order_date); ?></td>
                                    <td><?php echo e($payment->bank); ?></td>
                                    <td>Rp. <?php echo e(number_format($payment->total)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <img src="<?php echo e(url('images/bukti')); ?>/<?php echo e($payment->buktiPayment); ?>" width="400" alt="..."> 
                </div>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aneka\resources\views/detailPayment.blade.php ENDPATH**/ ?>