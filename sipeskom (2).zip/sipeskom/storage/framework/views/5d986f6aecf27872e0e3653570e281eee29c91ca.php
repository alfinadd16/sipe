<?php $__env->startSection('title'); ?>
Detail
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="item content mb-5">
    <div class="container toparea1">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Category Name</th>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Installation Costs</th>
                                    <th>Stock</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $spareparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sparepart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td style="color: #444;"><?php echo e($no++); ?></td>
                                    <td style="color: #444;"><?php echo e($sparepart->name); ?></td>
                                    <td style="color: #444;"><?php echo e($sparepart->name); ?></td>
                                    <td style="color: #444;">Rp. <?php echo e(number_format($sparepart->price)); ?>

                                        <?php if($sparepart->stock != null): ?>
                                        <span class="badge badge-success"> <i class="fas fa-check"></i> Ready Stock</span>
                                        <?php else: ?>
                                        <span class="badge badge-danger"> <i class="fas fa-times"></i> Out of Stock</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="color: #444;">Rp. <?php echo e(number_format($sparepart->biayaPemasangan)); ?></td>
                                    <td style="color: #444;"><?php echo e($sparepart->stock); ?> pcs</td>
                                    <td>
                                        <form method="post" action="<?php echo e(url('/sparepart/need')); ?>/<?php echo e($sparepart->id); ?>">
                                            <input type="text" name="total_sparepart" class="form-control" required="" style="background-color: white; width: 100px;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn" align="left" style="background: #8B0000; color: white;" <?php if($sparepart->stock == 0): ?> disabled <?php endif; ?>><i class="fas fa-shopping-cart"></i> Add</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asli\resources\views/admin/addSparepart.blade.php ENDPATH**/ ?>