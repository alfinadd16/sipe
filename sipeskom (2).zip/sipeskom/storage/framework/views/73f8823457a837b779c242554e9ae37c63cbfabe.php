<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="item header margin-top-0" style="background-image: url(images/komputer.jpg); width: 100%; " id="section-home" data-stellar-background-ratio="0.5">
	<div class="wrapper">
		<div class="container">
			<div class="row intro-text align-items-center justify-content-center">
				<div class="col-md-10 animated tada">
					<center>
						<h1 class="site-heading site-animate" style="font-size: 50px;">
							<strong class="d-block" data-scrollreveal="enter top over 1.5s after 0.1s">Service</strong>
                        </h1>
                        <h1 class="site-heading site-animate" style="font-size: 50px;">
                            <strong class="d-block" data-scrollreveal="enter top over 1.5s after 0.1s">MS Komputer Subang</strong>
                        </h1>
					</center><br><br>
					<div class="item content">
						<div class="container text-center">
						</div>
					</div>
					<br />
				</div>
			</div>
		</div>
	</div>
</header>
</div><br>
<!-- CONTENT =============================-->
<section class="item content">
	<div class="container toparea2">
	<div class="underlined-title">
		<div class="editContent">
			
		</div>
		<div class="wow-hr type_long">
			<span class="wow-hr-h">
			<i class="fa fa-star"></i>
			<i class="fa fa-star"></i>
			<i class="fa fa-star"></i>
			</span>
		</div>
	</div>
	</div><br>
</section>
</div><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipeskom\resources\views/home.blade.php ENDPATH**/ ?>