<?php $__env->startSection('title'); ?>
Invoice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
<h1 style="color: black">Input Invoice</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--div class="col-md-12">
    <a href="<?php echo e(url('bookingdata')); ?>" class="btn" style=" background:  darkcyan; color: white;">Back</a>
</div-->
<div class="col-md-12">
    <div class="card mt-2">
        <div class="card-body" style="color: black;">
            <?php if(!empty($booking)): ?>
            <div class="col-md-12">
                <div class="form-group row mb-0 mt-0">
                    <div class="col-md-12 offset-md-0">
                        <a href="/addSparepart" class="btn" style=" width: 200px;font-weight: bold; font-size: 16px; background:  black; color: white;">
                            Tambah Barang
                        </a>
                    </div>
                </div>
                <br>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama</th>
                                <th>Kuantitas</th>
                                <th>Harga</th>
                                <th>Harga Jasa</th>
                                <th>Total Harga</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody >
                            <?php $no = 1; ?>
                            <?php $__currentLoopData = $service_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($service_detail->sparepart->name); ?></td>
                                <td><?php echo e($service_detail->total_sparepart); ?> buah</td>
                                <td>Rp. <?php echo e(number_format($service_detail->sparepart->price)); ?> </td>
                                <td>Rp. <?php echo e(number_format($service_detail->biayaPemasangan)); ?></td>
                                <td>Rp. <?php echo e(number_format($service_detail->total_price)); ?></td>
                            <td>
                                <form action=" <?php echo e(url('sparepartDelete')); ?>/<?php echo e($service_detail->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Hapus Sparepart ?');"><i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div><br>

                <div class="form-group row mb-0 mt-0">
                    <!--div class="col-md-12">
                        <a href="/addTypeService" class="btn" style=" width: 200px;font-weight: bold; font-size: 16px; background:  black; color: white;">
                            Tambah Jenis Servis
                        </a>
                    </div-->
                </div><br>

                <div class="card">
                    <div class="card-body">

                        <!--table class="table table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Servis</th>
                                <th align=" right">Harga</th>
                            <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $detailJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailJeniss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($detailJeniss->jenisService->name); ?></td>
                                    <td>Rp. <?php echo e(number_format($detailJeniss->jenisService->price)); ?></td>
                                    <td>
                                        <form action="<?php echo e(url('serviceDelete')); ?>/<?php echo e($detailJeniss->id); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Hapus Jenis Servis?');"><i class="fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table-->
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tbody>
                                <!--tr>
                                    <td colspan="4" align="right"><strong>Total Jasa Servis :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->priceService)); ?></strong></td>
                                </tr-->
                                <tr>
                                    <td colspan="4" align="right"><strong>Total Biaya Servis :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->total_price)); ?></strong></td>
                                </tr>
                        <form method="POST" action="<?php echo e(url('InvoiceCompleted')); ?>/<?php echo e($booking->id); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('POST')); ?>

                            </tbody>
                        </table>
                            <div class="form-group">
                                <div class="col-md-24 offset-md-0">
                                    <button type="submit" class="btn" style=" width: 175px;font-weight: bold; font-size: 18px; background:  darkcyan; color: white;">
                                        Kirim
                                    </button>
                                </div>
                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <br>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 style="color: darkcyan;">Detail Booking :</h4>
                            <table class="table">
                                <tbody>
                                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>No Urut</td>
                                        <td>:</td>
                                        <td><?php echo e($booking->queue); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Tanggal</td>
                                        <td>:</td>
                                        <td><?php echo e($booking->service_date); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Nama Pemilik</td>
                                        <td>:</td>
                                        <td><?php echo e($booking->nama_pemilik); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Nama Barang</td>
                                        <td>:</td>
                                        <td><?php echo e($booking->nama_barang); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipeskom\resources\views/admin/invoice.blade.php ENDPATH**/ ?>