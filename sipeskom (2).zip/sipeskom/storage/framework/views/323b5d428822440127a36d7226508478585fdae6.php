<?php $__env->startSection('title'); ?>
Tentang
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="container-fluid page-header mt-5 p-1" style="background-color:black;">
        <div class="container-fluid page-header-inner py-5">
            <div class="container text-center mt-2">
                <br><br><br>
                <h1 class="display-3 text-white mb-3 animated tada">Tentang</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center text-uppercase">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('katalog')); ?>">Katalog</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('buatbooking')); ?>">Buat Booking</li>
                    </ol>
                </nav>
            </div>
        </div>
</header>
<br>
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="d-flex bg-light py-5 px-4">
                    <i class="fa fa-certificate fa-3x text-primary flex-shrink-0"></i>
                    <div class="ps-4">
                        <h5 class="mb-3">Berkualitas</h5>
                        <p> </p>
                        <a class="text-secondary border-bottom" href="<?php echo e(url('buatbooking')); ?>">Hasil reparasi dari bengkel kami sudah terjamin kualitasnya</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="d-flex bg-light py-5 px-4">
                    <i class="fa fa-users-cog fa-3x text-primary flex-shrink-0"></i>
                    <div class="ps-4">
                        <h5 class="mb-3">Terpercaya</h5>
                        <p> </p>
                        <a class="text-secondary border-bottom" href="<?php echo e(url('buatbooking')); ?>">Telah beroperasi selama 10 tahun</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="d-flex bg-light py-5 px-4">
                    <i class="fa fa-tools fa-3x text-primary flex-shrink-0"></i>
                    <div class="ps-4">
                        <h5 class="mb-3">Terjamin</h5>
                        <p> </p>
                        <a class="text-secondary border-bottom" href="<?php echo e(url('buatbooking')); ?>">Jaminan suku cadang orisinil dan hasil reparasi memuaskan</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 pt-4" style="min-height: 400px;">
                <div class="position-relative h-100 wow fadeIn" data-wow-delay="0.1s">
                    <img class="position-absolute img-fluid w-100 h-100" src ="images/bengkel.jpeg" style="object-fit: cover;background-color:darkcyan;" alt="">
                    <div class="position-absolute top-0 end-0 mt-n4 me-n4 py-4 px-5" style="background: rgb(52,144,220);">
                        <h1 class="display-4 text-white mb-0" >10 <span class="fs-4">Tahun</span></h1>
                        <h4 class="text-white">Telah Beroperasi</h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <h6 class="text-primary text-uppercase">// About Us //</h6>
                <h1 class="mb-4"><span class="text-primary"></span> Sekilas Tentang kami</h1>
                <p class="mb-4" style="justify-content: center"> DS Motor merupakan usaha bengkel yang berlokasi di Kp. Krajan Cinangsi, Kec. Cibogo dan telah berdiri sejak tahun 2010. Bisnis bengkel ini beroperasi selama seminggu penuh, sekitar rata-rata 8 jam operasional perharinya. Bengkel ini hanya melayani reparasi terkait sepeda motor dan menjual berbagai jenis suku cadang terkait kebutuhan sepeda motor.</p>
                <a href="<?php echo e(url('buatbooking')); ?>" class="btn btn-primary py-3 px-5" style="background-color: black;">Buat Booking</a>
            </div>
        </div>
    </div>
</div>
<br>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simubeng\resources\views/tentang.blade.php ENDPATH**/ ?>