<?php $__env->startSection('title'); ?>
Pembayaran
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <br><br><br>
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(url('/home')); ?>" class="btn btn-success">Back</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('history')); ?>"> Daftar Booking</a></li>
                    <li class="breadcrumb-item active" aria-current="page"> Bayar</li>
                </ol>
            </nav>
        </div>
        <div class="col-md-12 mt-2">
            <div class="card shadow" >
                <div class="card-body" style="color: black;">
                    <p>Transfer Menuju Salah Satu Akun berikut :</p>
                    <div class="media">
                        <div class="media-body">
                            <h5 class="mt-0" style="color: black;">BANK BRI : A.N. Bian Austin | Nomor Rekening : 0003549111</strong></h5>
                            <h5 class="mt-0" style="color: black;">BANK BNI : A.N. Bian Austin | Nomor Rekening : 0006789077</strong></h5>
                            <h5 class="mt-0" style="color: black;">BANK BSI : A.N. Bian Austin | Nomor Rekening : 0054231807</strong></h5>
                            <h5 class="mt-0" style="color: black;">Gopay : A.N. Bian Austin | Nomor : 089522339988</strong></h5>
                            <h5 class="mt-0" style="color: black;">Shopee Pay : A.N. Bian Austin | Nama : BianAustin</strong></h5>
                            <h5 class="mt-0" style="color: black;">Dana : A.N. Bian Austin | Nomor : 089522339988</strong></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h4 style="color: black;">Form Pembayaran</h4>
                    <br>
                    <form method="POST" action="<?php echo e(url('payment')); ?>/<?php echo e($service->id); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <label for="namaRek" class="col-md-2 col-form-label text-md-right">Nama :</label>

                            <div class="col">
                                <input placeholder="Input Nama Di Sini..." style="background-color: #ecebeb; color: black;" id="namaRek" type="text" class="form-control <?php $__errorArgs = ['namaRek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="namaRek">

                                <?php $__errorArgs = ['namaRek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="bank" class="col-md-2 col-form-label text-md-right">Nama Bank :</label>

                            <div class="col">
                                <input placeholder="Ditransfer Melalui Bank..." style="background-color: #ecebeb; color: black;" id="email" type="text" class="form-control <?php $__errorArgs = ['bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bank">

                                <?php $__errorArgs = ['bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="total" class="col-md-2 col-form-label text-md-right">Total :</label>
                            <?php if(!empty($service)): ?>
                            <h2 style="color: green; font-size: 15pt;">(Harga : Rp. <?php echo e(number_format($service->total_price)); ?>)</h2>
                            <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?> <br />
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                            <div class="col">
                                <input placeholder="Total Bayar..." style="background-color: #ecebeb; color: black;" id="total" type="text" class="form-control <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="total">

                                <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="buktiPayment" class="col-md-2 col-form-label text-md-right">Bukti Pembayaran :</label>

                            <div class="col">
                                <input value="Upload" placeholder="Input Gambar" style="background-color: #ecebeb; color: black;" id="buktiPayment" type="file" class="form-control <?php $__errorArgs = ['buktiPayment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="buktiPayment">

                                <?php $__errorArgs = ['buktiPayment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-12 offset-md-2">
                                <button type="submit" class="btn btn-success">
                                    Kirim
                                </button>
                            </div>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simubeng\resources\views/payment.blade.php ENDPATH**/ ?>