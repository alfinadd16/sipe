<?php $__env->startSection('title'); ?>
Booking Servis
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
Halaman kelola Booking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card  shadow mb-4">
                    
                    <div class="card-body">
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap" id="datatable">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Customer</th>
                                        <th>Tanggal</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1; ?>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($service->name); ?></td>
                                        <td><?php echo e($service->service_date); ?></td>
                                        <td>
                                            <?php echo e($service->status); ?>

                                            <br>
                                            <?php if($service->queue != null): ?>
                                            No : <?php echo e($service->queue); ?>

                                        </td>
                                        <?php endif; ?>
                                        <td>
                                            <?php if($service->status == 'pending' || $service->status == 'Being serviced' || $service->status == 'Queue available'): ?>
                                            <a href="<?php echo e(url('bookingdata/detail')); ?>/<?php echo e($service->id); ?>" class="btn" style="background: darkcyan; color: white;"><i></i> Detail</a>
                                            <?php elseif($service->status == 'Service complete'): ?>
                                            <a href="<?php echo e(url('bookingdata/invoice')); ?>/<?php echo e($service->id); ?>" class="btn" style="background: darkcyan; color: white;"><i></i> Input Invoice</a>
                                            <?php elseif($service->status == 'Waiting for payment'): ?>
                                            <a href="<?php echo e(url('bookingdata/invoiceDone')); ?>/<?php echo e($service->id); ?>" class="btn" style="background: darkcyan; color: white;"><i></i>Invoice</a>
                                            <?php elseif($service->status == 'Already sent payment'||  $service->status == 'Waiting for payment'): ?>
                                            <a href="<?php echo e(url('seePayment')); ?>/<?php echo e($service->id); ?>" class="btn" style="background: darkcyan; color: white;"><i class="fa fa-info"></i> See Payment</a>
                                            <a href="<?php echo e(url('bookingdata/invoiceDone')); ?>/<?php echo e($service->id); ?>" class="btn" style="background: darkcyan; color: white;"><i class="fa fa-info"></i> Invoice</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asli\resources\views/admin/bookingdata.blade.php ENDPATH**/ ?>