<?php $__env->startSection('title'); ?>
Tentang
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="item3 header margin-top-0" style="background-image: url(images/bengkel.jpeg);  width: 100%; " id="section-home" data-stellar-background-ratio="0.5">
    <div class="wrapper">
        <div class="container">
            <div class="row intro-text align-items-center ">
                <div class="col-md-10 animated tada"><br><br><br><br>
                    <h1 class="site-heading site-animate" style="font-size: 67px;">
                        <strong class="d-block" data-scrollreveal="enter top over 1.5s after 0.1s">Tentang</strong>
                    </h1>
                </div>
            </div>
            <div class="item content">
                <div class="container rightarea">
                    <div class="col">
                        <h3 class="numbertext2">DS Motor</h3>
                        <hr style="background-color: white;">
                        <p style="color: white; font-family: 'Lucida Console', 'Courier New', monospace; font-size: 15px">
                            DS Motor merupakan usaha bengkel yang berlokasi di Kp. Krajan Cinangsi, Kec. Cibogo dan telah berdiri sejak tahun 2010. Bisnis bengkel ini beroperasi selama seminggu penuh, sekitar rata-rata 8 jam operasional perharinya. Bengkel ini hanya melayani reparasi terkait sepeda motor dan menjual berbagai jenis suku cadang terkait kebutuhan sepeda motor.
                        </p>
                        <h3 class="numbertext2">Email</h3>
                        <hr style="background-color: white;">
                        <p style="color: white; font-family: 'Lucida Console', 'Courier New', monospace; font-size: 15px">
                            dsmotor@gmail.com
                        </p>
                        <h3 class="numbertext2">Alamat</h3>
                        <hr style="background-color: white;">
                        <p style="color: white; font-family: 'Lucida Console', 'Courier New', monospace; font-size: 15px">
                            Kampung Krajan, RT 06/RW 02, Cinangsi, Kec. Cibogo, Kabupaten Subang, Jawa Barat
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\abc\resources\views/tentang.blade.php ENDPATH**/ ?>