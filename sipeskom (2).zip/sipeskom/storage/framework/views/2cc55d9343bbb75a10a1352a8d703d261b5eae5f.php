<?php $__env->startSection('title'); ?>
Laporan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
    <h5 style="color: black; float:left;">Laporan Pendapatan
    <br>
    <strong>( <?php echo e(tanggal_indonesia($tanggalAwal, false)); ?> s/d <?php echo e(tanggal_indonesia($tanggalAkhir, false)); ?> )</strong>
    </h5>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="box">
            <div class="box-header with-border">
                <!--button onclick="updatePeriode()" class="btn btn-info btn-xs btn-flat">Ubah Periode</button-->
                <a href="<?php echo e(route('laporan.export_pdf', [$tanggalAwal, $tanggalAkhir])); ?>" target="_blank" class="btn btn-success btn-xs btn-flat"><i class="fa fa-file-excel-o"></i> Cetak Laporan</a>
            </div>
            <br>
            <div class="box-body table-responsive">
                <table class="table table-stiped table-bordered">
                    <thead>
                        <th width="5%">No</th>
                        <th>Tanggal</th>
                        <th>Nama Customer</th>
                        <th>Nama Barang</th>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if ($__env->exists('admin.laporan.form')) echo $__env->make('admin.laporan.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
    let table;

    $(function () {
        table = $('.table').DataTable({
            responsive: true,
            processing: true,
            serverSide: true,
            autoWidth: false,
            ajax: {
                url: '<?php echo e(route('laporan.data', [$tanggalAwal, $tanggalAkhir])); ?>',
            },
            columns: [
                {data: 'DT_RowIndex', searchable: false, sortable: false},
                {data: 'tanggal'},
                {data: 'Nama Pemilik'},
                {data: 'Nama Barang'}
            ],
            dom: 'Brt',
            bSort: false,
            bPaginate: false,
        });

        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true
        });
    });

    function updatePeriode() {
        $('#modal-form').modal('show');
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipeskom\resources\views/admin/laporan/index.blade.php ENDPATH**/ ?>