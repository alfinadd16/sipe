<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <br><br><br>
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(url('history')); ?>" class="btn btn-success"><i class="fa fa-arrow-left"></i> Back</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('serviceHistory')); ?>">Service History</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Service Detail</li>
                </ol>
            </nav>
        </div>
        <div class="col-md-12">
            <div class="card mt-2">
                <div class="card-body" style="color: black;">
                    <?php if(!empty($booking)): ?>
                    <p>Id Service : <?php echo e($booking->id); ?> / Booking Date : <?php echo e($booking->service_date); ?></p>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 style="color: darkcyan;"><i class="fas fa-history" style="color: darkcyan;"></i> Service Detail</h4>
                                <table class="table">
                                    <tbody style="color: gray;">
                                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>Name of STNK</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->name_stnk); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Motorcycle Name</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->nama_motor); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Motorcycle Type</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->jenis_motor); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Motorcycle license plate</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->number_plat); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Complaint</td>
                                            <td>:</td>
                                            <td><?php echo e($booking->complaint); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <h5 style="color: darkcyan;">Service Action: </h5><br>
                                <table class="table table-striped">
                                    <thead style="color: gray;">
                                        <tr>
                                            <th>ServiceName</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody style="color: gray;">
                                        <?php $__currentLoopData = $detailJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailJeniss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td> <?php echo e($detailJeniss->serviceName); ?> </td>
                                            <td> Rp. <?php echo e(number_format($detailJeniss->price)); ?> </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php endif; ?>
                                <h5 style="color: darkcyan;">Spare parts needed : </h5><br>
                                <table class="table table-striped">
                                <thead>
                                 <tr style=" color: gray;">
                                    <th>No.</th>
                                    <th>Sparepart Name</th>
                                    <th>Total Sparepart</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; ?>
                                        <?php $__currentLoopData = $service_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="color: gray;">
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($service_detail->sparepart->name); ?></td>
                                            <td><?php echo e($service_detail->total_sparepart); ?> sparepart </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table><br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\abc\resources\views/detailService.blade.php ENDPATH**/ ?>