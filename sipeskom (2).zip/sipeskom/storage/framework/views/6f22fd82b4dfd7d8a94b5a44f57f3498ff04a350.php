<!DOCTYPE html>
<html>

<head>
    <title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <?php if(!empty($booking)): ?>
    <center>
        <p style="color: #008080;"><b style="font-size: 20px;">MS Komputer Subang </b><br> Jln.Arief Rahman Hakim<br> Telp. (026) 416126<br>HP.0823 1786 5550
        </p>
    </center>
    <hr style="color: gray;">
    <h6 style="color: gray; font-size: 15px; ">Urutan ke : <?php echo e($booking->queue); ?> <br> Tanggal Servis : <?php echo e($booking->service_date); ?> <br> Nama Pemilik : <?php echo e($booking->nama_pemilik); ?></h6>
    <br>
    <h4 style="color:  darkcyan;"> Invoice</h4>
    <table class="table">
        <tbody style="color: gray;">
            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><?php echo e($booking->alamat); ?></td>
            </tr>
            <tr>
                <td>No Telp/HP</td>
                <td>:</td>
                <td><?php echo e($booking->telp); ?></td>
            </tr>
            <tr>
                <td>Nama Barang</td>
                <td>:</td>
                <td><?php echo e($booking->nama_barang); ?></td>
            </tr>
            <tr>
                <td>Keluhan</td>
                <td>:</td>
                <td><?php echo e($booking->complaint); ?></td>
            </tr>
        </tbody>
    </table>
    <!--div style="color: darkcyan; font-weight:bold; font-size: 16px">
        Detail Servis
    </div--><br>
    <!--table class="table table-striped">
        <thead>
            <tr  style=" color: gray;">
                <th>Nama</th>
                <th>Harga</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $detailJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailJeniss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr  style=" color: gray;">
                <td> <?php echo e($detailJeniss->serviceName); ?> </td>
                <td> Rp. <?php echo e(number_format($detailJeniss->price)); ?> </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div style="color: darkcyan; font-weight:bold; font-size: 16px">
                        Detail Servis
                        </div><br>
    <table class='table table-striped'>
        <thead>
            <tr style=" color: gray;">
                <th>No.</th>
                <th>Nama</th>
                <th>Kuntitas</th>
                <th>Harga</th>
                <th style=" text-align: right;">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php $__currentLoopData = $service_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="color: gray;">
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($service_detail->sparepart->name); ?></td>
                <td><?php echo e($service_detail->total_sparepart); ?> Buah </td>
                <td>Rp. <?php echo e(number_format($service_detail->sparepart->price)); ?></td>
                <td align=" right">Rp. <?php echo e(number_format($service_detail->total_price)); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </tbody>
    </table>
    <table class='table table-striped'>
            <!--tr style="color: gray;">
                <td colspan=" 4" align="right"><strong>Harga Servis :</strong></td>
                <td align="right"><strong>Rp. <?php echo e(number_format($booking->priceService)); ?></strong></td>
            </tr-->
            <tr style="color: gray;">
                <td colspan=" 4" align="right"><strong>Total Biaya :</strong></td>
                <td align="right"><strong>Rp. <?php echo e(number_format($booking->total_price)); ?></strong></td>
            </tr>
        </tbody>
    </table><br>
    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\sipeskom\resources\views/invoice_pdf.blade.php ENDPATH**/ ?>