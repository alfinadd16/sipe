<?php $__env->startSection('title'); ?>
Invoice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
Invoice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    
    <?php if(!empty($booking)): ?>
    <a href="<?php echo e(url('bookingdata/invoice/print')); ?>/<?php echo e($booking->id); ?>" class="btn" style=" background:  darkcyan; color: white;" target="_blank">Print</a>
</div>
<div class="col-md-12">
    <div class="card mt-2">
        <div class="card-body" style="color: black;">
            <div class="col-md-12">
                <center>
                    <p style="color: #008080;"><b style="font-size: 20px;">MS Komputer Subang </b><br> Jln.Arief Rahman Hakim<br> Telp. (026) 416126<br>HP.0823 1786 5550
                    </p>
                </center>
                <div class="card">
                    <div class="card-body">
                        <h4 style="color: darkcyan;" <i style="color: darkcyan;"></i>Informasi Umum</h4>
                        <br>
                        <table class="table">
                            <tbody>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>No Urutan</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->queue); ?></td>
                                </tr>
                                <tr>
                                    <td>Tanggal</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->service_date); ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Pemilik</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->nama_pemilik); ?></td>
                                </tr>
                                <tr>
                                    <td>Alamat</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->alamat); ?></td>
                                </tr>
                                <tr>
                                    <td>No Telp/Hp</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->telp); ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Barang</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->nama_barang); ?></td>
                                </tr>
                                <tr>
                                    <td>Keluhan</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->complaint); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <br>
                        <!--div style="color: darkcyan; font-weight:bold; font-size: 16px">
                        Detil Servis
                        </div--><br>
                        <!--table class="table table-striped">
                            <thead>
                                <tr>
                                <th>Nama Servis</th>
                                <th>Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $detailJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailJeniss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($detailJeniss->serviceName); ?> </td>
                                    <td> Rp. <?php echo e(number_format($detailJeniss->price)); ?> </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <br>
                        <div style="color: darkcyan; font-weight:bold; font-size: 16px">
                        Detil Sparepart
                        </div><br>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama</th>
                                    <th>Kuantitas</th>
                                    <th>Harga</th>
                                    <th style=" text-align: right;">Total Harga</th>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $service_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($service_detail->sparepart->name); ?></td>
                                    <td><?php echo e($service_detail->total_sparepart); ?> Buah </td>
                                    <td>Rp. <?php echo e(number_format($service_detail->sparepart->price)); ?></td>
                                    <td align=" right">Rp. <?php echo e(number_format($service_detail->total_price)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <br>
                                <table class="table table-striped">
                                    <tbody>
                                <!--tr>
                                    <td colspan=" 4" align="right"><strong>Harga Servis :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->priceService)); ?></strong></td>
                                </tr-->
                                <tr>
                                    <td colspan=" 4" align="right"><strong>Total Harga :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->total_price)); ?></strong></td>
                                </tr>
                            </tbody>
                        </table><br>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipeskom\resources\views/admin/invoiceDone.blade.php ENDPATH**/ ?>