<?php $__env->startSection('title'); ?>
Invoice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <a href="<?php echo e(url('bookingdata')); ?>" class="btn" style=" background:  darkcyan; color: white;"><i class="fa fa-arrow-left"></i> Back</a>
</div>
<div class="col-md-12">
    <div class="card mt-2">
        <div class="card-body" style="color: black;">
            <?php if(!empty($booking)): ?>
            <div class="col-md-12">
                <center>
                    <p style="color: darkcyan;"><b style="font-size: 20px;">Bengkel DSM</b><br> Cibogo <br> No. HP : +62 857-8160-6016
                    </p>
                </center>
                <hr>
                <h6 style="color: gray;">No. Queue&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;: <?php echo e($booking->queue); ?> <br> Service Date &nbsp;&nbsp;&nbsp;&nbsp;: <?php echo e($booking->service_date); ?> <br> Name of STNK &nbsp;: <?php echo e($booking->name_stnk); ?></h6>
                <div class="card">
                    <div class="card-body">
                        <h4 style="color: darkcyan;" <i class="fas fa-receipt" style="color: darkcyan; font-weight:bold"></i> Invoice</h4>
                        <table class="table">
                            <tbody>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>Motorcycle Name</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->nama_motor); ?></td>
                                </tr>
                                <tr>
                                    <td>Motorcycle Type</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->jenis_motor); ?></td>
                                </tr>
                                <tr>
                                    <td>Motorcycle license plate</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->number_plat); ?></td>
                                </tr>
                                <tr>
                                    <td>Complaint</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->complaint); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><br>
            <div class="col-md-12">
                <div class="form-group row mb-0 mt-0">
                    <div class="col-md-12 offset-md-0">
                        <a href="/addSparepart" class="btn" style=" width: 200px;font-weight: bold; font-size: 16px; background:  black; color: white;">
                            Add Spareparts
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><br>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Sparepart Name</th>
                                <th>Total Sparepart</th>
                                <th>Price</th>
                                <th>Installation Costs</th>
                                <th>Total Price</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody >
                            <?php $no = 1; ?>
                            <?php $__currentLoopData = $service_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($service_detail->sparepart->name); ?></td>
                                <td><?php echo e($service_detail->total_sparepart); ?> sparepart</td>
                                <td>Rp. <?php echo e(number_format($service_detail->sparepart->price)); ?> </td>
                                <td>Rp. <?php echo e(number_format($service_detail->biayaPemasangan)); ?></td>
                                <td align=" right">Rp. <?php echo e(number_format($service_detail->total_price)); ?></td>
                            <td>
                                <form action=" <?php echo e(url('sparepartDelete')); ?>/<?php echo e($service_detail->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete data?');"><i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div><br>
                <div class="form-group row mb-0 mt-0">
                    <div class="col-md-12 offset-md-0">
                        <a href="/addTypeService" class="btn" style=" width: 200px;font-weight: bold; font-size: 16px; background:  black; color: white;">
                            Add Type of Service
                        </a>
                    </div>
                </div><br>
                <div class="card">
                    <div class="card-body">

                        <table class="table table-striped"">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Name of Service</th>
                                <th align=" right">Price</th>
                            <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $detailJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailJeniss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($detailJeniss->jenisService->name); ?></td>
                                    <td align="right">Rp. <?php echo e(number_format($detailJeniss->jenisService->price)); ?></td>
                                    <td>
                                        <form action="<?php echo e(url('serviceDelete')); ?>/<?php echo e($detailJeniss->id); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete data?');"><i class="fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="2" align="right"><strong>Total Service Fee :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->priceService)); ?></strong></td>
                                </tr>
                                <tr>
                                    <td colspan="2" align="right"><strong>Total :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->total_price)); ?></strong></td>
                                </tr>
                            </tbody>
                        </table>
                        <form method="POST" action="<?php echo e(url('InvoiceCompleted')); ?>/<?php echo e($booking->id); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('POST')); ?>

                            <div class="form-group row mb-0 mt-0">
                                <div class="col-md-12 offset-md-0">
                                    <button type="submit" class="btn" style=" width: 940px;font-weight: bold; font-size: 16px; background:  darkcyan; color: white;">
                                        Send
                                    </button>
                                </div>
                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asli\resources\views/admin/invoice.blade.php ENDPATH**/ ?>