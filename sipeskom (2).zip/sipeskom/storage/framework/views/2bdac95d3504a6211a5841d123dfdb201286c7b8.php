<?php $__env->startSection('content'); ?>
<section class="item content mb-5">
    <div class="container toparea1">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                    <h4 style="color: #8B0000; font-weight:bold" >Type of Service</h4><br>
                        <table class="table table-striped">
                            <thead>
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Service Name</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $jenisServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td style="color: #444;"><?php echo e($no++); ?></td>
                                    <td style="color: #444;"><?php echo e($jenisService->name); ?></td>
                                    <td style="color: #444;">Rp <?php echo e(number_format($jenisService->price)); ?></td>
                                    <td>
                                        <form method="post" action="<?php echo e(url('/TypeService')); ?>/<?php echo e($jenisService->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn" align="left" style="background: #8B0000; color: white;">Add</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aneka\resources\views/admin/addTypeService.blade.php ENDPATH**/ ?>