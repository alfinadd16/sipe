<?php $__env->startSection('title'); ?>
Servis
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="item1 header margin-top-0" style="background-color:rgb(123, 146, 199);  width: 100%;
    height: 500px; " id="section-home" data-stellar-background-ratio="0.5">
    <div class="wrapper">
        <div class="container">
            <div class="row intro-text align-items-center justify-content-center">
                <div class="col-md-10 animated tada">
                    <center>
                        <h1 class="site-heading site-animate" style="font-size: 47px;">
                            <strong class="d-block" data-scrollreveal="enter top over 1.5s after 0.1s">Progres Service</strong>
                        </h1><br><br><br><br><br><br><br>
                    </center>
                </div>
            </div>
        </div>
    </div>
</header>
<section class="item content">
    <div class="container toparea1">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Nama Barang</th>
                                    <th>Tanggal Servis</th>
                                    <th>Status</th>
                                    <th>Detail</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td style="color: #444;"><?php echo e($no++); ?></td>
                                    <td style="color: #444;"><?php echo e($booking->nama_barang); ?></td>
                                    <td style="color: #444;"><?php echo e($booking->service_date); ?></td>
                                    <td style="color: #444;">
                                        <?php echo e($booking->status); ?>

                                        <br>
                                        <?php if($booking->queue != null): ?>
                                        No : <?php echo e($booking->queue); ?>

                                    </td>
                                    <?php endif; ?>
                                    <td style="color: #444;">
                                        <?php if($booking->status == 'pending'): ?>
                                        <?php elseif($booking->status == 'Being serviced' || $booking->status == 'Queue available'): ?>
                                        <a href="<?php echo e(url('invoice')); ?>/<?php echo e($booking->id); ?>" class="btn btn-success"><i></i>Invoice</a>
                                       
                                        <?php elseif($booking->status == 'Service complete' || $booking->status == 'Waiting for payment'): ?>
                                        <a href="<?php echo e(url('invoice')); ?>/<?php echo e($booking->id); ?>" class="btn btn-success"><i></i>Invoice</a>
                                        <!--a href="<?php echo e(url('payment')); ?>/<?php echo e($booking->id); ?>" class="btn btn-success" <i class="fa fa-info"></i>Bayar</a-->

                                        <?php elseif($booking->status == 'Already sent payment'): ?>
                                        <!--a href="<?php echo e(url('invoice')); ?>/<?php echo e($booking->id); ?>" class="btn btn-success">Invoice</a>
                                        <a href="<?php echo e(url('history/seePayment')); ?>/<?php echo e($booking->id); ?>" class="btn btn-success">Detail Bayar</a-->

                                        <?php elseif($booking->status == 'Payment confirmed'): ?>
                                        <a href="<?php echo e(url('invoice')); ?>/<?php echo e($booking->id); ?>" class="btn btn-success">Invoice</a>

                                        <?php elseif($booking->status == 'Paid offline'): ?>
                                        <a href="<?php echo e(url('invoice')); ?>/<?php echo e($booking->id); ?>" class="btn btn-success">Invoice</a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#delete<?php echo e($booking->id); ?>" type="hidden">Hapus</button>
                                    </td></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="modal-body" style="color: black">
                                    <p>Apakah anda ingin menghapus data ini?</p>
                                  </div>
                                  <div class="modal-footer justify-content-between">
                                      <input type="hidden" name="_method" value="DELETE">
                                    <a href="<?php echo e(url('invoice')); ?>/<?php echo e($booking->id); ?>" class="btn btn-outline-light" type="submit">Hapus</a>  
                                    
                                      <button type="button" class="btn btn-outline-light" data-dismiss="modal">No</button>
                                  </div>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipeskom\resources\views/history.blade.php ENDPATH**/ ?>