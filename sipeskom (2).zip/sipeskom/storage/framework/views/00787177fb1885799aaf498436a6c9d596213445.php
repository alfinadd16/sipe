<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <a href="<?php echo e(url('bookingdata')); ?>" class="btn" style=" background:  darkcyan; color: white;"><i class="fa fa-arrow-left"></i> Back</a>
    <?php if(!empty($booking)): ?>
    <a href="<?php echo e(url('bookingdata/invoice/print')); ?>/<?php echo e($booking->id); ?>" class="btn" style=" background:  darkcyan; color: white;" target="_blank"><i class="fas fa-print"></i> Print PDF</a>
</div>
<div class="col-md-12">
    <div class="card mt-2">
        <div class="card-body" style="color: black;">
            <div class="col-md-12">
                <center>
                    <p style="color: #008080;"><b style="font-size: 20px;">Bengkel DSM </b><br> Cibogo<br> 081234567810
                    </p>
                </center>
                <hr>
                <h6 style="color: gray;">Urutan ke&nbsp;: <?php echo e($booking->queue); ?> <br> Tanggal servis&nbsp;: <?php echo e($booking->service_date); ?> <br> STNK : <?php echo e($booking->name_stnk); ?></h6>
                <div class="card">
                    <div class="card-body">
                        <h4 style="color: darkcyan;" <i class="fas fa-receipt" style="color: darkcyan;"></i> Invoice</h4>
                        <table class="table">
                            <tbody>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>Name</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->nama_motor); ?></td>
                                </tr>
                                <tr>
                                    <td>Type</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->jenis_motor); ?></td>
                                </tr>
                                <tr>
                                    <td>Plat</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->number_plat); ?></td>
                                </tr>
                                <tr>
                                    <td>Keluhan</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->complaint); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <div style="color: darkcyan; font-weight:bold; font-size: 16px">
                        Detil Servis
                        </div><br>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                <th>Nama Servis</th>
                                <th>Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $detailJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailJeniss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($detailJeniss->serviceName); ?> </td>
                                    <td> Rp. <?php echo e(number_format($detailJeniss->price)); ?> </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div style="color: darkcyan; font-weight:bold; font-size: 16px">
                        Detil Sparepart
                        </div><br>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama</th>
                                    <th>Total</th>
                                    <th>Harga</th>
                                    <th style=" text-align: right;">Total Harga</th>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $service_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($service_detail->sparepart->name); ?></td>
                                    <td><?php echo e($service_detail->total_sparepart); ?> sparepart </td>
                                    <td>Rp. <?php echo e(number_format($service_detail->sparepart->price)); ?></td>
                                    <td align=" right">Rp. <?php echo e(number_format($service_detail->total_price)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan=" 4" align="right"><strong>Service Harga :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->priceService)); ?></strong></td>
                                </tr>
                                <tr>
                                    <td colspan=" 4" align="right"><strong>Total Harga :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->total_price)); ?></strong></td>
                                </tr>
                            </tbody>
                        </table><br>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\abc\resources\views/admin/invoiceDone.blade.php ENDPATH**/ ?>