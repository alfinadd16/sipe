<?php $__env->startSection('title'); ?>
Invoice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br><br><br><br>
<div class="col-md-12">
    <a href="<?php echo e(url('history')); ?>" class="btn" style=" background:  darkcyan; color: white;">kembali</a>
    <?php if(!empty($booking)): ?>
    <a href="<?php echo e(url('invoice/print')); ?>/<?php echo e($booking->id); ?>" class="btn" style=" background: darkcyan; color: white;" target="_blank">PDF</a>
</div>
<div class="col-md-12">
    <div class="card mt-2">
        <div class="card-body" style="color: black;">
            <div class="col-md-12">
                <center>
                    <p style="color: #008080;"><b style="font-size: 20px;">MS'Computer Subang </b><br> Jln.Arief Rahman Hakim<br> Telp. (026) 416126<br>HP.0823 1786 5550
                    </p>
                </center>
                <hr>
                <h6 style="color: gray;">Antrian Ke&nbsp;: <?php echo e($booking->queue); ?> <br> Tanggal Servis&nbsp;: <?php echo e($booking->service_date); ?> <br> Nama Pemilik &nbsp;: <?php echo e($booking->name_stnk); ?></h6>
                <div class="card">
                    <div class="card-body">
                        <h4 style="color: darkcyan;" <i style="color: darkcyan;"></i>Invoice</h4>
                        <table class="table">
                            <tbody style="color: gray;">
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>Alamat</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->nama_motor); ?></td>
                                </tr>
                                <tr>
                                    <td>No Telp/HP</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->jenis_motor); ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Barang</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->number_plat); ?></td>
                                </tr>
                                <tr>
                                    <td>Keluhan</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->complaint); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <!--div style="color: darkcyan; font-weight:bold; font-size: 16px">
                        Detail Servis
                        </div--><br>
                        <!--table class="table table-striped">
                            <thead>
                                <tr style="color: gray;">
                                <th>Nama</th>
                                <th>Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $detailJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailJeniss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="color: gray;">
                                    <td> <?php echo e($detailJeniss->serviceName); ?> </td>
                                    <td> Rp. <?php echo e(number_format($detailJeniss->price)); ?> </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div style="color: darkcyan; font-weight:bold; font-size: 16px">
                        Detail Barang
                        </div><br>
                        <table class="table table-striped">
                            <thead>
                                <tr style="color: gray;">
                                    <th>No.</th>
                                    <th>Nama</th>
                                    <th>Kuantitas</th>
                                    <th>Harga</th>
                                    <th>Total</th>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $service_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="color: gray;">
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($service_detail->sparepart->name); ?></td>
                                    <td><?php echo e($service_detail->total_sparepart); ?> Buah </td>
                                    <td>Rp. <?php echo e(number_format($service_detail->sparepart->price)); ?></td>
                                    <td>Rp. <?php echo e(number_format($service_detail->total_price)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr style="color: gray;">
                                    <td colspan=" 4" align="right"><strong>Harga Servis :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->priceService)); ?></strong></td>
                                </tr>
                                <tr style="color: gray;">
                                    <td colspan=" 4" align="right"><strong>Total Biaya :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($booking->total_price)); ?></strong></td>
                                </tr>
                            </tbody>
                        </table><br>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simubeng\resources\views/invoice.blade.php ENDPATH**/ ?>