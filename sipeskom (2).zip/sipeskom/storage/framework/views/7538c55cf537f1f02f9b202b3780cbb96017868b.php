<?php $__env->startSection('title'); ?>
Barang
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
<br><br><br>
    <div class="row mb-2">
        <div class="mb-2 col-11">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active text-dark" aria-current="page" >Katalog Barang</li>
                    <div class="col-md-7" style="position: absoulte; top: 5%; left: 62%">
                        <br>
                        <div class="input-group mb-5">
                        <form action="<?php echo e(url('cari')); ?>" method="GET">
                            <input type="text" name="name" placeholder="Cari Di sini..." class="form-control bg-light" style="color: black;" >
                        </form>
                            <div class="input-group-prepend">
                                <span class="input-group-text"  style="background-color: darkcyan;" id="basic-addon1">
                                    <i class="fas fa-search" style="color: white;"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </ol>
            </nav>
        </div>
    </div>
<section class="item content mb-5">
<br><br><br><br><br><br><br><br>
    <div class="container toparea1">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Harga</th>
                                    <th>Biaya Jasa</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $spareparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sparepart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td style="color: #444;"><?php echo e($no++); ?></td>
                                    <td style="color: #444;"><?php echo e($sparepart->name); ?></td>
                                    <td style="color: #444;">Rp. <?php echo e(number_format($sparepart->price)); ?></td>
                                    <td style="color: #444;">Rp. <?php echo e(number_format($sparepart->biayaPemasangan)); ?></td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simubeng\resources\views/katalog.blade.php ENDPATH**/ ?>