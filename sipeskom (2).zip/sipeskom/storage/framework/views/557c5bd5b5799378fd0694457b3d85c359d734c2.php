<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header py-3">
                    <div class="card-header py-3">
                        <div class="col-md-12">
                            <h6 class="m-0 font-weight-bold" style="color: 	#8B0000;"> <i class="far fa-address-book"></i> Contact Me</h6>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>No</th>
                                <th> Name</th>
                                <th>Email</th>
                                <th>Date</th>
                                <th>Message</th>
                                <th>Reply</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center" style="color: gray;">
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($contact->name); ?></td>
                                <td><?php echo e($contact->email); ?></td>
                                <td><?php echo e($contact->created_at); ?></td>
                                <td><?php echo e($contact->pesan); ?></td>
                                <td align="right">
                                    <?php if($contact->reply == null): ?>
                                    <form method="POST" action="<?php echo e(url('/message/reply')); ?>/<?php echo e($contact->id); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <textarea placeholder="Enter admin reply..." required="" style="color: gray;" id="reply" class="form-control <?php $__errorArgs = ['reply'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="reply"></textarea>

                                        <button type="submit" class="btn btn-primary"> Send</button>
                                    </form>
                                    <?php elseif($contact->reply != null): ?>
                                    <?php echo e($contact->reply); ?>

                                    <?php endif; ?>
                                </td>
                                <td style="color: #444;">
                                    <form action="<?php echo e(url('/message/delete')); ?>/<?php echo e($contact->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn" style="background-color:#8B0000; color: white;"><i style="color: white;" class="fa fa-trash"></i> Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\abc\resources\views/admin/contact.blade.php ENDPATH**/ ?>