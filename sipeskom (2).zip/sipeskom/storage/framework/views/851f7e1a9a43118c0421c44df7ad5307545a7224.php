<?php $__env->startSection('title'); ?>
Detail
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
Edit Booking
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <a href="<?php echo e(url('bookingdata')); ?>" class="btn" style=" background:  darkcyan; color: white;">Back</a>
</div>
<div class="col-md-12">
    <div class="card mt-2">
        <div class="card-body" style="color: black;">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(url('bookingdata/detail/input_queue')); ?>/<?php echo e($booking->id); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="status" class="col-md-5 col-form-label" style="color: darkcyan;" align = "right">Pilih Status</label>

                                <div class="col-md-7">
                                    <select style="width: 100%;  padding: 12px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;  resize: vertical; color: gray;" name="status">
                                        <option value="">Pilih Status</option>
                                        
                                        <?php if($booking->status == 'pending'): ?>
                                        <option value="Queue available">Queue available</option>
                                        <option value="Being serviced">Being serviced</option>
                                        <option value="Service complete">Service complete</option>
                                        <option value="Payment confirmed">Payment confirmed</option>
                                        <?php elseif($booking->status == 'Queue available'): ?>
                                        <option value="Being serviced">Being serviced</option>
                                        <option value="Service complete">Service complete</option>
                                        <option value="Payment confirmed">Payment confirmed</option>
                                        <?php elseif($booking->status == 'Being serviced'): ?>
                                        <option value="Service complete">Service complete (cashless)</option>
                                        <option value="Payment confirmed">Payment confirmed (cash)</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="queue" class="col-md-5 col-form-label" style="color: darkcyan;" align = "right">Pilih Urutan</label>

                                <div class="col-md-7">
                                    <input placeholder="Input Nomor Antrian" style="background-color: #ecebeb; color: gray;" id="queue" type="text" value="<?php echo e($booking->queue); ?>" class="form-control <?php $__errorArgs = ['queue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="queue" >

                                    <?php $__errorArgs = ['queue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row mb-0 mt-0">
                                <div class="col-md-12 offset-md-0" align="right">
                                    <button type="submit" class="btn" style=" width: 100px;font-weight: bold; font-size: 16px; background:  #141212; color: white;">
                                        Save
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php if(!empty($booking)): ?>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h4 style="color: darkcyan;">Detail Booking :</h4>
                        <br>
                        <table class="table">
                            <tbody>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>Status</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->status); ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Pemilik</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->name_stnk); ?></td>
                                </tr>
                                <tr>
                                    <td>Tanggal Servis</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->service_date); ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Kendaraan</td>
                                    <td>:</td>
                                    <td><?php echo e($booking->nama_motor); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simubeng\resources\views/admin/bookingdetail.blade.php ENDPATH**/ ?>