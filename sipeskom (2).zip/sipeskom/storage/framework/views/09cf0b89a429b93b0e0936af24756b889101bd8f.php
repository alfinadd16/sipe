<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="item header margin-top-0" style="background-image: url(images/bengkel.jpeg); width: 100%; " id="section-home" data-stellar-background-ratio="0.5">
	<div class="wrapper">
		<div class="container">
			<div class="row intro-text align-items-center justify-content-center">
				<div class="col-md-10 animated tada">
					<center>
						<h1 class="site-heading site-animate" style="font-size: 50px;">
							Servis Kendaraan Roda Dua<strong class="d-block" data-scrollreveal="enter top over 1.5s after 0.1s">DS Motor</strong></h1>

					</center><br><br>
					<div class="item content">
						<div class="container text-center">
							<a href="<?php echo e(url('booking')); ?>" class="homebrowseitems">Pesan Servis
								<div class="">
									<i class=""></i>
								</div>
							</a>
						</div>
					</div>
					<br />
				</div>
			</div>
		</div>
	</div>
</header>

<div class="item content">
	<div class="container toparea">
		<div class="row text-center">
			<div class="col-md-4">
				<div class="col editContent">
					<span class="numberstep"><i class="far fa-laugh-beam"></i></span>
					<h3 class="numbertext">a</h3>
					<p>
						lorem ipsum
				</div>
				<!-- /.col-md-4 -->
			</div>
			<!-- /.col-md-4 col -->
			<div class="col-md-4 editContent">
				<div class="col">
					<span class="numberstep"><i class="far fa-calendar-alt"></i></i></span>
					<h3 class="numbertext">b</h3>
					<p>
						lorem ipsum
					</p>
				</div>
				<!-- /.col -->
			</div>
			<!-- /.col-md-4 col -->
			<div class="col-md-4 editContent">
				<div class="col">
					<span class="numberstep"><i class="fas fa-tags"></i></i></span>
					<h3 class="numbertext">c</h3>
					<p>
						lorem (use ipsum).
					</p>
				</div>
			</div>
		</div>
	</div>
</div><br><br>
<!-- CONTENT =============================-->
<section class="item content">
	<div class="container toparea2">
	<div class="underlined-title">
		<div class="editContent">
			<h1 class="text-center latestitems">TEST</h1>
		</div>
		<div class="wow-hr type_long">
			<span class="wow-hr-h">
			<i class="fa fa-star"></i>
			<i class="fa fa-star"></i>
			<i class="fa fa-star"></i>
			</span>
		</div>
	</div>
		<div class="row">
			<div class="col-md-8">
				<div class="productbox2">
					<img src="images/getstarted.jpeg" alt="" width="100%">
					<div class="clearfix">
					</div>
					<br />
					<div class="product-details text-left">
						<p style="font-size: 15px; color: #444; text-align:justify;"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
							Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<h2 class="btn btn-buynow">Daftar Servis</h2>
				<div class="properties-box">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama Servis</th>
								<th>Harga</th>
							</tr>
						</thead>
						<tbody>
							<?php $no = 1; ?>
							<?php $__currentLoopData = $jenis_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis_service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td style="color: #444;"><?php echo e($no++); ?></td>
								<td style="color: #444;"><?php echo e($jenis_service->name); ?></td>
								<td style="color: #444;">Rp. <?php echo e(number_format($jenis_service->price)); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div><br>
</section>
<!-- LATEST ITEMS =============================-->
</div><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\abc\resources\views/home.blade.php ENDPATH**/ ?>