<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Admin\BookingDataController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Admin\InvoiceController;
use App\Http\Controllers\Admin\SparepartController;
use App\Http\Controllers\Admin\TypeServiceController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\HistoryController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\KatalogController;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ProfilController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\TentangController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('landing');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/tentang', [App\Http\Controllers\TentangController::class, 'index'])->name('tentang');
Route::get('/profil', [App\Http\Controllers\ProfilController::class, 'index'])->name('profil');
Route::post('/profil',  [App\Http\Controllers\ProfilController::class, 'updatecustomer']);
Route::get('/buatbooking',  [App\Http\Controllers\ServiceController::class, 'index']);
Route::post('/buatbooking/{id}',  [App\Http\Controllers\ServiceController::class, 'save']);
Route::get('/history', [App\Http\Controllers\HistoryController::class, 'index'])->name('history');
Route::get('history/{id}', [App\Http\Controllers\HistoryController::class, 'detail']);
Route::post('/historyEdit/{id}',  [App\Http\Controllers\HistoryController::class, 'update']);
Route::get('payment/{id}', [App\Http\Controllers\PaymentController::class, 'index']);
Route::get('history/seePayment/{id}', [App\Http\Controllers\PaymentController::class, 'seePayment']);
Route::post('payment/{id}', [App\Http\Controllers\PaymentController::class, 'save']);
Route::get('invoice/{id}', [App\Http\Controllers\HistoryController::class, 'invoice']);
Route::get('/invoice/print/{id}', [App\Http\Controllers\HistoryController::class, 'cetak_pdf']);
Route::get('/riwayat',  [App\Http\Controllers\HistoryController::class, 'index_service'])->name('riwayat');
Route::get('detailriwayat/{id}', [App\Http\Controllers\HistoryController::class, 'detail_service']);
Route::get('/katalog', [App\Http\Controllers\KatalogController::class, 'render'])->name('katalog');
Route::get('cari', [App\Http\Controllers\KatalogController::class, 'cari']);
Route::get('/katalog/category/{category}', [App\Http\Controllers\KategoriController::class, 'render'])->name('katalog.category');

Route::group(['middleware' => 'auth'], function() {
    Route::get('/admin/home', [App\Http\Controllers\HomeController::class, 'adminHome'])->name('admin.home');
    Route::get('/profilAdmin', [App\Http\Controllers\ProfilController::class, 'indexAdmin'])->name('profilAdmin');
    Route::post('/profilAdmin',  [App\Http\Controllers\ProfilController::class, 'updateadmin']);
    Route::group(['middleware' => 'is_admin'], function () {
        Route::resource('pengguna', App\Http\Controllers\Admin\CustomerController::class);
        Route::resource('jenisservis', App\Http\Controllers\Admin\TypeServiceController::class);
        Route::resource('kategori', App\Http\Controllers\Admin\CategoryController::class);
        Route::resource('sparepart', App\Http\Controllers\Admin\SparepartController::class);
        Route::resource('supplier', App\Http\Controllers\SupplierController::class);
      Route::get('/laporan', [App\Http\Controllers\LaporanController::class, 'index'])->name('laporan.index');
        Route::get('/laporan/data/{awal}/{akhir}', [App\Http\Controllers\LaporanController::class, 'data'])->name('laporan.data');
        Route::get('/laporan/pdf/{awal}/{akhir}', [App\Http\Controllers\LaporanController::class, 'exportPDF'])->name('laporan.export_pdf');
    });
    Route::group(['middleware' => 'is_kasir'], function() {
        Route::get('bookingdata', [App\Http\Controllers\Admin\BookingDataController::class, 'index'])->name('bookingdata');
        Route::get('bookingdata/detail/{id}', [App\Http\Controllers\Admin\BookingDataController::class, 'detailBooking']);
        Route::post('bookingdata/detail/input_queue/{id}', [App\Http\Controllers\Admin\BookingDataController::class, 'saveSQ']);
        Route::get('bookingdata/invoice/{id}', [App\Http\Controllers\Admin\InvoiceController::class, 'indexInputInvoice']);
        Route::get('/addSparepart', [App\Http\Controllers\Admin\InvoiceController::class, 'indextambahSp']);
        Route::get('/addTypeService', [App\Http\Controllers\Admin\InvoiceController::class, 'indextambahJs']);
        Route::post('/sparepart/need/{id}', [App\Http\Controllers\Admin\InvoiceController::class, 'saveSp']);
        Route::post('/TypeService/{id}', [App\Http\Controllers\Admin\InvoiceController::class, 'saveJs']);
        Route::delete('sparepartDelete/{id}',  [App\Http\Controllers\Admin\InvoiceController::class, 'deleteSp']);
        Route::delete('serviceDelete/{id}',  [App\Http\Controllers\Admin\InvoiceController::class, 'deleteJs']);
        Route::post('InvoiceCompleted/{id}', [App\Http\Controllers\Admin\InvoiceController::class, 'confirm']);
        Route::get('seePayment/{id}', [App\Http\Controllers\Admin\BookingDataController::class, 'seePayment']);
        Route::get('bookingdata/invoiceDone/{id}', [App\Http\Controllers\Admin\InvoiceController::class, 'seeInvoice']);
        Route::get('bookingdata/invoice/print/{id}', [App\Http\Controllers\Admin\BookingDataController::class, 'printPdf']);
       
    });
});
