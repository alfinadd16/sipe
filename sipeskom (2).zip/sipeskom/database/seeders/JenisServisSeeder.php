<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class JenisServisSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('jenis_services')->insert([
            'name' => 'Ganti Oli',
            'price' => '40000'
        ]);
        DB::table('jenis_services')->insert([
            'name' => 'Tune Up',
            'price' => '400000'
        ]);
    }
}
