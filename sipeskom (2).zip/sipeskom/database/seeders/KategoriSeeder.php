<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class KategoriSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
            'name' => 'Honda',
        ]);
        DB::table('categories')->insert([
            'name' => 'Yamaha',
        ]);
        DB::table('categories')->insert([
            'name' => 'Tesla',
        ]);
        DB::table('categories')->insert([
            'name' => 'Harley',
        ]);
    }
}
