<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SparepartSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('spareparts')->insert([
            'category_id' => 1,
            'name' => 'Filter Udara',
            'price' => '32000',
            'biayaPemasangan' => '20000',
            'stock' => 14
        ]);


        DB::table('spareparts')->insert([
            'category_id' => 1,
            'name' => 'Kampas Rem Depan',
            'price' => '41000',
            'biayaPemasangan' => '32000',
            'stock' => 20
        ]);

        DB::table('spareparts')->insert([
            'category_id' => 3,
            'name' => 'Kampas Rem Belakang',
            'price' => '63000',
            'biayaPemasangan' => '32000',
            'stock' => 10
        ]);


        DB::table('spareparts')->insert([
            'category_id' => 2,
            'name' => 'Kampas Kopling Set',
            'price' => '110000',
            'biayaPemasangan' => '32000',
            'stock' => 91
        ]);


        DB::table('spareparts')->insert([
            'category_id' => 3,
            'name' => 'Bohlam Lampu Depan',
            'price' => '114000',
            'biayaPemasangan' => '15000',
            'stock' => 37
        ]);

        DB::table('spareparts')->insert([
            'category_id' => 4,
            'name' => 'Ring Piston',
            'price' => '45000',
            'biayaPemasangan' => '40000',
            'stock' => 54
        ]);
    }
}
