<!DOCTYPE html>
<html>

<head>
    <title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    @if(!empty($booking))
    <center>
        <p style="color: #008080;"><b style="font-size: 20px;">MS Komputer Subang </b><br> Jln.Arief Rahman Hakim<br> Telp. (026) 416126<br>HP.0823 1786 5550
        </p>
    </center>
    <hr style="color: gray;">
    <h6 style="color: gray; font-size: 15px; ">Urutan ke : {{ $booking->queue }} <br> Tanggal Servis : {{ $booking->service_date }} <br> Nama Pemilik : {{ $booking->nama_pemilik }}</h6>
    <br>
    <h4 style="color:  darkcyan;"> Invoice</h4>
    <table class="table">
        <tbody style="color: gray;">
            @foreach($bookings as $booking)
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td>{{ $booking->alamat }}</td>
            </tr>
            <tr>
                <td>No Telp/HP</td>
                <td>:</td>
                <td>{{ $booking->telp }}</td>
            </tr>
            <tr>
                <td>Nama Barang</td>
                <td>:</td>
                <td>{{ $booking->nama_barang }}</td>
            </tr>
            <tr>
                <td>Keluhan</td>
                <td>:</td>
                <td>{{ $booking->complaint }}</td>
            </tr>
        </tbody>
    </table>
    <!--div style="color: darkcyan; font-weight:bold; font-size: 16px">
        Detail Servis
    </div--><br>
    <!--table class="table table-striped">
        <thead>
            <tr  style=" color: gray;">
                <th>Nama</th>
                <th>Harga</th>
            </tr>
        </thead>
        <tbody>
            @foreach($detailJenis as $detailJeniss)
            <tr  style=" color: gray;">
                <td> {{ $detailJeniss->serviceName }} </td>
                <td> Rp. {{ number_format($detailJeniss->price)}} </td>
            </tr>
            @endforeach
        </tbody>
    </table-->
    @endforeach
    <div style="color: darkcyan; font-weight:bold; font-size: 16px">
                        Detail Servis
                        </div><br>
    <table class='table table-striped'>
        <thead>
            <tr style=" color: gray;">
                <th>No.</th>
                <th>Nama</th>
                <th>Kuntitas</th>
                <th>Harga</th>
                <th style=" text-align: right;">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            @foreach($service_details as $service_detail)
            <tr style="color: gray;">
                <td>{{ $no++ }}</td>
                <td>{{ $service_detail->sparepart->name }}</td>
                <td>{{ $service_detail->total_sparepart }} Buah </td>
                <td>Rp. {{ number_format($service_detail->sparepart->price) }}</td>
                <td align=" right">Rp. {{ number_format($service_detail->total_price) }}</td>
                @endforeach
            </tr>
        </tbody>
    </table>
    <table class='table table-striped'>
            <!--tr style="color: gray;">
                <td colspan=" 4" align="right"><strong>Harga Servis :</strong></td>
                <td align="right"><strong>Rp. {{ number_format($booking->priceService) }}</strong></td>
            </tr-->
            <tr style="color: gray;">
                <td colspan=" 4" align="right"><strong>Total Biaya :</strong></td>
                <td align="right"><strong>Rp. {{ number_format($booking->total_price) }}</strong></td>
            </tr>
        </tbody>
    </table><br>
    @endif

</body>

</html>
