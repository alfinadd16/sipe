@extends('layouts.app')
@section('title')
Booking
@endsection
@section('content')
<header class="item1 header margin-top-0" style="background-color:rgb(165, 175, 213);  width: 100%;
    height: 500px; " id="section-home" data-stellar-background-ratio="0.5">
	<div class="wrapper">
		<div class="container">
			<div class="row intro-text align-items-center justify-content-center">
				<div class="col-md-10 animated tada">
					<center>
						<h1 class="site-heading site-animate"  style="font-size: 47px;">
							<strong class="d-block" data-scrollreveal="enter top over 1.5s after 0.1s">Form Pemesanan Service</strong>
						</h1><br><br><br><br>
					</center>
				</div>
			</div>
		</div>
	</div>
</header>
<!-- CONTENT =============================-->
<section class="item content">
	<div class="container toparea">
		<div class="underlined-title">
			<div class="editContent">
				<h1 class="text-center latestitems" style="font-size: 18px;">Isi Data Berikut :</h1>
			</div>
            <br>
		</div>
		<div class="row">
			<div class="col-md-12 mt-2">
				<form method="POST" action="{{ url('buatbooking') }}/{{ auth()->user()->id }}" id="contactform">
					{{ csrf_field() }}
					<div class="form">
						<div class="col">
							<input class="place @error('nama_pemilik') is-invalid @enderror" type="text" name="nama_pemilik" placeholder="Nama Pemilik" required autocomplete="nama_pemilik">
							@error('nama_pemilik')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
							@enderror
						</div>
						<div class="col">
							<input class="place  @error('nama_barang') is-invalid @enderror" type="text" name="nama_barang" placeholder="Nama Barang" required autocomplete="nama_barang">
							@error('nama_barang')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
							@enderror
						</div>

						<div class="col">
							<input class="place  @error('alamat') is-invalid @enderror" type="text" name="alamat" placeholder="Alamat" required autocomplete="alamat">
							@error('alamat')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
							@enderror
						</div>
						<div class="col">
							<input class="place  @error('telp') is-invalid @enderror" type="text" name="telp" placeholder="No Telephone/HP" required autocomplete="telp">
							@error('telp')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
							@enderror
						</div>
						<div class="col">
							<input class="place @error('service_date') is-invalid @enderror" type="date" name="service_date" placeholder="Tanggal Servis" required autocomplete="service_date">
							@error('service_date')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
							@enderror
						</div>
						<div class="col">
							<textarea class="place @error('service_complaint') is-invalid @enderror" name="complaint" rows="7" placeholder="Isi keluhan" required autocomplete="complaint"></textarea>
							@error('complaint')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
							@enderror
						</div>
						<button coolspan = "5" type="submit" id="submit" class="clearfix btn" value="Kirim">Kirim</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	</div>
</section><br><br>
@endsection
