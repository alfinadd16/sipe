@extends('layouts.app')
@section('title')
Invoice
@endsection
@section('content')
<br><br><br><br>
<div class="col-md-12">
    
    @if(!empty($booking))
    <a href="{{ url('invoice/print') }}/{{ $booking->id }}" class="btn" style=" background: darkcyan; color: white;" target="_blank">Print</a>
</div>
<div class="col-md-12">
    <div class="card mt-2">
        <div class="card-body" style="color: black;">
            <div class="col-md-12">
                <center>
                    <p style="color: #008080;"><b style="font-size: 20px;">MS Komputer Subang </b><br> Jln.Arief Rahman Hakim<br> Telp. (026) 416126<br>HP.0823 1786 5550
                    </p>
                </center>
                <hr>
                <h6 style="color: gray;">Antrian Ke&nbsp;: {{ $booking->queue }} <br> Tanggal Servis&nbsp;: {{ $booking->service_date }} <br> Nama Pemilik &nbsp;: {{ $booking->nama_pemilik }}</h6>
                <div class="card">
                    <div class="card-body">
                        <h4 style="color: darkcyan;" <i style="color: darkcyan;"></i>Invoice</h4>
                        <table class="table">
                            <tbody style="color: gray;">
                                @foreach($bookings as $booking)
                                <tr>
                                    <td>Alamat</td>
                                    <td>:</td>
                                    <td>{{ $booking->alamat }}</td>
                                </tr>
                                <tr>
                                    <td>No Telp/HP</td>
                                    <td>:</td>
                                    <td>{{ $booking->telp }}</td>
                                </tr>
                                <tr>
                                    <td>Nama Barang</td>
                                    <td>:</td>
                                    <td>{{ $booking->nama_barang }}</td>
                                </tr>
                                <tr>
                                    <td>Keluhan</td>
                                    <td>:</td>
                                    <td>{{ $booking->complaint }}</td>
                                </tr>
                            </tbody>
                        </table>
                      
                        @endforeach
                        <div style="color: darkcyan; font-weight:bold; font-size: 16px">
                        Detail Barang
                        </div><br>
                        <table class="table table-striped">
                            <thead>
                                <tr style="color: gray;">
                                    <th>No.</th>
                                    <th>Nama</th>
                                    <th>Kuantitas</th>
                                    <th>Harga</th>
                                    <th>Total</th>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                @foreach($service_details as $service_detail)
                                <tr style="color: gray;">
                                    <td>{{ $no++ }}</td>
                                    <td>{{ $service_detail->sparepart->name }}</td>
                                    <td>{{ $service_detail->total_sparepart }} Buah </td>
                                    <td>Rp. {{ number_format($service_detail->sparepart->price) }}</td>
                                    <td>Rp. {{ number_format($service_detail->total_price) }}</td>
                                </tr>
                                @endforeach
                                <!--tr style="color: gray;">
                                    <td colspan=" 4" align="right"><strong>Harga Servis :</strong></td>
                                    <td align="right"><strong>Rp. {{ number_format($booking->priceService) }}</strong></td>
                                </tr-->
                                <tr style="color: gray;">
                                    <td colspan=" 4" align="right"><strong>Total Biaya :</strong></td>
                                    <td align="right"><strong>Rp. {{ number_format($booking->total_price) }}</strong></td>
                                </tr>
                            </tbody>
                        </table><br>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
