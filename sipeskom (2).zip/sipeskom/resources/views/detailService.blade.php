@extends('layouts.app')
@section('title')
Detail
@endsection
@section('content')
<div class="container py-4">
    <br><br><br>
    <div class="row">
        <!--div class="col-md-12">
            <a href="{{ url('riwayat') }}" class="btn btn-success">Back</a>
        </div-->
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/home') }}">Home</a></li>
                    <li class="breadcrumb-item"><a href="{{ url('/riwayat') }}">Riwayat</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detail Riwayat</li>
                </ol>
            </nav>
        </div>
        <div class="col-md-12">
            <div class="card mt-2">
                <div class="card-body" style="color: black;">
                    @if(!empty($booking))
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 style="color: darkcyan;"><i style="color: darkcyan;"></i> Detail Servis</h4>
                                <table class="table">
                                    <tbody style="color: gray;">
                                        @foreach($bookings as $booking)
                                        <tr>
                                            <td>Id Servis</td>
                                            <td>:</td>
                                            <td>{{ $booking->id }}</td>
                                        </tr>
                                        <tr>
                                            <td>Tanggal Servis</td>
                                            <td>:</td>
                                            <td>{{ $booking->service_date }}</td>
                                        </tr>
                                        <tr>
                                            <td>Nama Pemilik</td>
                                            <td>:</td>
                                            <td>{{ $booking->nama_pemilik }}</td>
                                        </tr>
                                        <tr>
                                            <td>Nama Barang</td>
                                            <td>:</td>
                                            <td>{{ $booking->nama_barang}}</td>
                                        </tr>
                                        <tr>
                                            <td>Alamat</td>
                                            <td>:</td>
                                            <td>{{ $booking->alamat}}</td>
                                        </tr>
                                        <tr>
                                            <td>telp</td>
                                            <td>:</td>
                                            <td>{{ $booking->telp }}</td>
                                        </tr>
                                        <tr>
                                            <td>Keluhan</td>
                                            <td>:</td>
                                            <td>{{ $booking->complaint }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                <br>
                                <h5 style="color: darkcyan;">Jasa Servis Yang Digunakan: </h5><br>
                                <table class="table table-striped">
                                    <thead style="color: gray;">
                                        <tr>
                                            <th>Nama</th>
                                            <th>Harga</th>
                                        </tr>
                                    </thead>
                                    <tbody style="color: gray;">
                                        @foreach($detailJenis as $detailJeniss)
                                        <tr>
                                            <td> {{ $detailJeniss->serviceName }} </td>
                                            <td> Rp. {{ number_format($detailJeniss->price)}} </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                @endif
                                <br>
                                <h5 style="color: darkcyan;">Barang Yang Digunakan : </h5><br>
                                <table class="table table-striped">
                                <thead>
                                 <tr style=" color: gray;">
                                    <th>No.</th>
                                    <th>Nama</th>
                                    <th>Kuantitas</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; ?>
                                        @foreach($service_details as $service_detail)
                                        <tr style="color: gray;">
                                            <td>{{ $no++ }}</td>
                                            <td>{{ $service_detail->sparepart->name }}</td>
                                            <td>{{ $service_detail->total_sparepart }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table><br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><br><br><br>
@endsection
