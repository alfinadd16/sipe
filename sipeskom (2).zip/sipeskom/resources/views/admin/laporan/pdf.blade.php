<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{--  <head>
        <link rel="stylesheet" href="{{ asset('template') }}/datepicker/dist/css/bootstrap-datepicker.min.css">
        <script src="{{ asset('template') }}/moment/min/moment.min.js"></script>
        <script src="js/validator.min.js"></script>
        <link rel="stylesheet" href="{{ asset('template') }}/vendor/bootstrap/dist/css/bootstrap.min.css">
        </head>  --}}
    <title>Laporan Pemesanan</title>

</head>
<body>
    <h3 class="text-center">Laporan Pemesanan</h3>
    <h4 class="text-center">
        Tanggal {{ tanggal_indonesia($awal, false) }}
        s/d
        Tanggal {{ tanggal_indonesia($akhir, false) }}
    </h4>

    <table class="table table-striped">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th>Tanggal</th>
                <th>Service</th>
                <th>Pendapatan</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data as $row)
                <tr>
                    @foreach ($row as $col)
                        <td>{{ $col }}</td>
                    @endforeach
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
