@extends('layouts.adminApp')
@section('title')
Detail
@endsection
@section('page')
Input Invoice
@endsection
@section('content')
<div class="col-md-12">

</div>
<div class="col-md-12">
    <div class="card mt-2">
        <div class="card-body" style="color: black;">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="{{ url('bookingdata/detail/input_queue') }}/{{ $booking->id }}" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group row">
                                <label for="status" class="col-md-5 col-form-label" style="color: rgb(87, 176, 143);" align = "right">Pilih Status</label>

                                <div class="col-md-7">
                                    <select style="width: 100%;  padding: 12px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;  resize: vertical; color: gray;" name="status">
                                        <option value="">Pilih Status</option>
                                        {{--  <option value="pending">pending</option>  --}}
                                        @if($booking->status == 'pending')
                                        <option value="Queue available">Queue available</option>
                                        <option value="Being serviced">Being serviced</option>
                                        <option value="Service complete">Service complete</option>
                                        <option value="Payment confirmed">Payment confirmed</option>
                                        @elseif($booking->status == 'Queue available')
                                        <option value="Being serviced">Being serviced</option>
                                        <option value="Service complete">Service complete</option>
                                        <option value="Payment confirmed">Payment confirmed</option>
                                        @elseif($booking->status == 'Being serviced')
                                        <option value="Service complete">Service complete (cashless)</option>
                                        <option value="Payment confirmed">Payment confirmed (cash)</option>
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="queue" class="col-md-5 col-form-label" style="color: rgb(87, 176, 143);" align = "right">Pilih Urutan</label>

                                <div class="col-md-7">
                                    <input placeholder="Input Nomor Antrian" style="background-color: #ecebeb; color: gray;" id="queue" type="text" value="{{ $booking->queue }}" class="form-control @error('queue') is-invalid @enderror" name="queue" >

                                    @error('queue')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group row mb-0 mt-0">
                                <div class="col-md-12 offset-md-0" align="right">
                                    <button type="submit" class="btn" style=" width: 100px;font-weight: bold; font-size: 16px; background:  #141212; color: white;">
                                        Save
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            @if(!empty($booking))
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h4 style="color: rgb(87, 176, 143);">Detail Booking :</h4>
                        <br>
                        <table class="table">
                            <tbody>
                                @foreach($bookings as $booking)
                                <tr>
                                    <td>Status</td>
                                    <td>:</td>
                                    <td>{{ $booking->status }}</td>
                                </tr>
                                <tr>
                                    <td>Nama Pemilik</td>
                                    <td>:</td>
                                    <td>{{ $booking->nama_pemilik }}</td>
                                </tr>
                                <tr>
                                    <td>Tanggal Servis</td>
                                    <td>:</td>
                                    <td>{{ $booking->service_date }}</td>
                                </tr>
                                <tr>
                                    <td>Nama Barang</td>
                                    <td>:</td>
                                    <td>{{ $booking->nama_barang }}</td>
                                @endforeach
                            </tbody>
                        </table>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

@endsection
