@extends('layouts.adminApp')
@section('title')
Booking Servis
@endsection
@section('page')
kelola Pemesanan
@endsection
@section('content')


<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card  shadow mb-4">
                    <div class = "card-header py-3">
                        <h6 class="m-0 font-weight-bold" style="color: 	darkcyan;">Data Pemesanan</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="bookingTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Pelanggan</th>
                                        <th>Tanggal</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1; ?>
                                    @foreach ($services as $service)
                                    <tr>
                                        <td>{{ $no++ }}</td>
                                        <td>{{ $service->name }}</td>
                                        <td>{{ $service->service_date }}</td>
                                        <td>
                                            {{ $service->status }}
                                            <br>
                                            @if($service->queue != null)
                                            No : {{ $service->queue }}
                                        </td>
                                        @endif
                                        <td>
                                            @if($service->status == 'pending' || $service->status == 'Being serviced' || $service->status == 'Queue available')
                                            <a href="{{ url('bookingdata/detail') }}/{{ $service->id }}" class="btn" style="background: rgb(87, 176, 143); color: white;"><i></i> Input Invoice</a>
                                            @elseif($service->status == 'Service complete')
                                            <a href="{{ url('bookingdata/invoice') }}/{{ $service->id }}" class="btn" style="background: rgb(87, 176, 143); color: white;"><i></i> Input Invoice</a>
                                            @elseif($service->status == 'Waiting for payment')
                                            <a href="{{ url('bookingdata/invoiceDone') }}/{{ $service->id }}" class="btn" style="background: rgb(87, 176, 143); color: white;"><i></i>Invoice</a>
                                            @elseif($service->status == 'Already sent payment'||  $service->status == 'Waiting for payment')
                                            <!--a href="{{ url('seePayment') }}/{{ $service->id }}" class="btn" style="background: darkcyan; color: white;">Lihat Pembayaran</a>
                                            <a href="{{ url('bookingdata/invoiceDone') }}/{{ $service->id }}" class="btn" style="background: darkcyan; color: white;">Invoice</a-->
                                            @elseif($service->status == 'Payment confirmed')
                                            <a href="{{ url('bookingdata/invoice') }}/{{ $service->id }}" class="btn" style="background: rgb(87, 176, 143); color: white;"><i></i> Input Invoice</a>
                                            <a href="{{ url('bookingdata/invoiceDone') }}/{{ $service->id }}" class="btn" style="background: rgb(87, 176, 143); color: white;">Invoice</a>
                                            @elseif ($service->status == 'Paid offline')
                                            <a href="{{ url('bookingdata/invoiceDone') }}/{{ $service->id }}" class="btn" style="background: rgb(87, 176, 143); color: white;">Invoice</a>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>

{{--  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>  --}}
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

@endsection
