<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIPESKOM</title>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a87e9d7c5f.js" crossorigin="anonymous"></script>
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{!! asset('css/main.css') !!}">
    <link href="{!! asset('css/style.css') !!}" rel="stylesheet">
</head>

<body class="antialiased">
    <center>
    <div class="limiter">
        <div class="container-login100" style="background-image: url(images/komputer.jpg) ;">
            <div class="container">
                <div class="row intro-text align-items-center justify-content-center">
                    <div class="col-md-18 animated tada">
                        <h1><strong class="d-block" style="color: white;">Selamat Datang Di</h1>
                            <h1><strong class="d-block" style="color: white;">Website MS Komputer Subang</h1>
                                <h1><strong class="d-block" style="color: white;">Klik Masuk Untuk Login</h1>
                            
                        <div class="container-login100-form-btn3 col-5">
                            <a href="{{ route('login') }}">
                                <button class="login100-form-btn">Masuk</button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </center>
</body>
</html>
