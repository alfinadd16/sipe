@extends('layouts.app')
@section('title')
Detail
@endsection
@section('content')
<div class="container py-4">
    <br><br><br>
    <div class="row">
        <div class="col-md-12">
            <a href="{{ url('history') }}" class="btn btn-success"><i class="fa fa-arrow-left"></i> Backatuch</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/home') }}">Home</a></li>
                    <li class="breadcrumb-item"><a href="{{ url('history') }}">Daftar Booking</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detail</li>
                </ol>
            </nav>
        </div>
        <div class="col-md-12">
            <div class="card mt-2">
                <div class="card-body" style="color: black;">
                    @if(!empty($booking))
                    <p  style="color: #008080">Status : {{ $booking->status }} / Pemilik : {{ $booking->name_stnk }} </p>
                    <p >Nomor Booking : {{ $booking->id }} / Tanggal : {{ $booking->service_date }}</p><br>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 style="color: darkcyan;">&nbsp;&nbsp;Booking Detail</h4>

                                <table class="table">
                                    <tbody>
                                        @foreach($bookings as $booking)
                                        <tr>
                                            <td>Nama</td>
                                            <td>:</td>
                                            <td>{{ $booking->name_stnk }}</td>
                                        </tr>
                                        <tr>
                                            <td>Nama Kendaraan</td>
                                            <td>:</td>
                                            <td>{{ $booking->nama_motor }}</td>
                                        </tr>
                                        <tr>
                                            <td>Jenis Kendaraan</td>
                                            <td>:</td>
                                            <td>{{ $booking->jenis_motor }}</td>
                                        </tr>
                                        <tr>
                                            <td>Nomor Plat</td>
                                            <td>:</td>
                                            <td>{{ $booking->number_plat }}</td>
                                        </tr>
                                        <tr>
                                            <td>Keluhan</td>
                                            <td>:</td>
                                            <td>{{ $booking->complaint }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 style="color: darkcyan;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Edit Booking</h4>
                    <br>
                    <form method="POST" action="{{ url('historyEdit') }}/{{ $booking->id }}">
                        @csrf

                        <div class="form-group row">
                            <label for="name_stnk" class="col-md-2 col-form-label text-md-right">Nama Pemilik</label>

                            <div class="col-md-6">
                                <input style="background-color: #ecebeb; color: black;" id="name_stnk" type="text" class="form-control @error('name_stnk') is-invalid @enderror" name="name_stnk" value="{{ $booking->name_stnk }}">

                                @error('name_stnk')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="number_plat" class="col-md-2 col-form-label text-md-right">Nama Pemilik</label>

                            <div class="col-md-6">
                                <input style="background-color: #ecebeb; color: black;" id="nama_pemilik" type="text" class="form-control @error('nama_pemilik') is-invalid @enderror" name="nama_pemilik" value="{{ $booking->nama_pemilik }}">

                                @error('nama_pemilik')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="name_motor" class="col-md-2 col-form-label text-md-right">Nama Barang</label>

                            <div class="col-md-6">
                                <input style="background-color: #ecebeb; color: black;" id="nama_barang" type="text" class="form-control @error('nama_barang') is-invalid @enderror" name="nama_barang" value="{{ $booking->nama_barang}}" required autocomplete="nama_barang">

                                @error('nama_barang')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="jenis_motor" class="col-md-2 col-form-label text-md-right">Jenis Kendaraan</label>

                            <div class="col-md-6">
                                <input style="background-color: #ecebeb; color: black;" id="jenis_motor" type="text" class="form-control @error('jenis_motor') is-invalid @enderror" name="jenis_motor" value="{{ $booking->jenis_motor }}" required autocomplete="jenis_motor" autofocus>

                                @error('jenis_motor')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="complaint" class="col-md-2 col-form-label text-md-right">Keluhan</label>

                            <div class="col-md-6">
                                <textarea style="background-color: #ecebeb; color: black;" name="complaint" class="form-control @error('complaint') is-invalid @enderror" required="">{{ $booking->complaint }}</textarea>

                                @error('complaint')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>



                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-2">
                                <button type="submit" class="btn btn-success" style="width: 100%; font-weight: bold; font-size: 16px;">
                                    Simpan
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><br><br><br>
@endsection
