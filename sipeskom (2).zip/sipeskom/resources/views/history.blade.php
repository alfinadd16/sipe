@extends('layouts.app')
@section('title')
Servis
@endsection
@section('content')
<header class="item1 header margin-top-0" style="background-color:rgb(123, 146, 199);  width: 100%;
    height: 500px; " id="section-home" data-stellar-background-ratio="0.5">
    <div class="wrapper">
        <div class="container">
            <div class="row intro-text align-items-center justify-content-center">
                <div class="col-md-10 animated tada">
                    <center>
                        <h1 class="site-heading site-animate" style="font-size: 47px;">
                            <strong class="d-block" data-scrollreveal="enter top over 1.5s after 0.1s">Progres Service</strong>
                        </h1><br><br><br><br><br><br><br>
                    </center>
                </div>
            </div>
        </div>
    </div>
</header>
<section class="item content">
    <div class="container toparea1">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Nama Barang</th>
                                    <th>Tanggal Servis</th>
                                    <th>Status</th>
                                    <th>Detail</th>
                                  
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                @foreach($bookings as $booking)
                                <tr class="text-center">
                                    <td style="color: #444;">{{ $no++ }}</td>
                                    <td style="color: #444;">{{ $booking->nama_barang }}</td>
                                    <td style="color: #444;">{{ $booking->service_date }}</td>
                                    <td style="color: #444;">
                                        {{$booking->status}}
                                        <br>
                                        @if($booking->queue != null)
                                        No : {{ $booking->queue}}
                                    </td>
                                    @endif
                                    <td style="color: #444;">
                                        @if($booking->status == 'pending')
                                        @elseif($booking->status == 'Being serviced' || $booking->status == 'Queue available')
                                        <a href="{{ url('invoice') }}/{{ $booking->id }}" class="btn btn-success"><i></i>Invoice</a>
                                       
                                        @elseif($booking->status == 'Service complete' || $booking->status == 'Waiting for payment')
                                        <a href="{{ url('invoice') }}/{{ $booking->id }}" class="btn btn-success"><i></i>Invoice</a>
                                        <!--a href="{{ url('payment') }}/{{ $booking->id }}" class="btn btn-success" <i class="fa fa-info"></i>Bayar</a-->

                                        @elseif($booking->status == 'Already sent payment')
                                        <!--a href="{{ url('invoice') }}/{{ $booking->id }}" class="btn btn-success">Invoice</a>
                                        <a href="{{ url('history/seePayment') }}/{{ $booking->id }}" class="btn btn-success">Detail Bayar</a-->

                                        @elseif($booking->status == 'Payment confirmed')
                                        <a href="{{ url('invoice') }}/{{ $booking->id }}" class="btn btn-success">Invoice</a>

                                        @elseif($booking->status == 'Paid offline')
                                        <a href="{{ url('invoice') }}/{{ $booking->id }}" class="btn btn-success">Invoice</a>
                                        @endif
                                    </td>
                                    <td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><br><br>

@endsection
